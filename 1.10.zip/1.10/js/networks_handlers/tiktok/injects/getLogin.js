let nickname = window.__$UNIVERSAL_DATA$__.__DEFAULT_SCOPE__['webapp.app-context'].user?.uniqueId;
document.currentScript.dataset.data = nickname === undefined ? '0' : nickname;