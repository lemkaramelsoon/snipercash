import {Helpers} from "../common/helpers.js";
import {Settings} from "../common/settings.js";
import {debug, debugError, debugInfo} from "../common/debug.js";

export class BaseNetworkHandler {
  tab;
  yaSuccessCompleteTag = 'extension_network_success_complete';
  yaErrorCompleteTag = 'extension_network_error_complete';
  selectors = [];
  comments = [];

  async checkLogin() {
    return true;
  }

  async openTab(url, sleepAfterSeconds, forceActive = false) {
    return new Promise(async (resolve, reject) => {
      try {
        let tabWasUpdated = false;
        if (this.tab !== undefined) {
          if (forceActive) {
            try {
              chrome.tabs.remove([this.tab.id]);
            } catch (e) {}
          }
          else {
            tabWasUpdated = await new Promise(async (r) => {
              chrome.tabs.get(this.tab.id, () => r(chrome.runtime.lastError === undefined));
            });
            if (tabWasUpdated) {
              let currentTab = this.tab;
              chrome.tabs.update(this.tab.id, {url: url, active: true}, tabItem => {
                setTimeout(() => {resolve(true)}, 2000);
              });
            }
          }
        }

        if (!tabWasUpdated) {
          // для пк использовался pinned, что бы не засорять вкладки. Сделать ли опционально?
          // chrome.tabs.create({url: url, active: false, "pinned": true}, tabItem => {
          chrome.tabs.create({url: url, active: true}, tabItem => {
            if (tabItem) {
              this.tab = tabItem;
              setTimeout(() => {resolve(true)}, 2000);
            }
          });
        }
      } catch (e) {
        reject(e)
      }
    }).then(async (res) => {
      let setting = await Settings.getSettings();
      setting.network = this;
      if (res) {
        if (setting.isDebug) {
          this.overlayPopup(await setting.common.log)
        }
        else {
          this.overlayPopup()
          this.onCloseHandler()
        }
        if (sleepAfterSeconds) {
          await Helpers.sleep(sleepAfterSeconds);
        }
      }
      return res;
    })
  }

  onCloseHandler() {
    chrome.tabs.onRemoved.addListener((tabId, removalInfo) => {
      if (tabId === this.tab.id) {
        debugInfo('BaseNetworkHandler', 'close_tab', JSON.stringify(removalInfo))
      }
    });
  }

  overlayPopup(overlayText = 'TaskBot at work...') {
    this.scripting(
      (overlayText) => {
        let el = document.querySelector('#bot-liker-popup');
        if (el == null) {
          el = document.createElement('div');
          el.setAttribute("id", "bot-liker-popup");
          document.documentElement.appendChild(el);
        }

        el.innerHTML = `
        <style>.overlay{position:fixed;top:0;left:0;width:100%;height:100%;background-color:rgba(255,255,255,0.8);display:flex;justify-content:center;align-items:center;z-index:999999}.overlay-content{text-align:center;background-color:rgb(255 255 255 / 86%);border-radius:20px;padding:30px 20px 20px;box-shadow:0px 3px 26px -6px rgb(0 0 0 / 25%)}.overlay-text{font-size:14px;color:#333;margin-top:16px}.overlay-icon{width:50px;height:50px;animation:levitate 3s alternate infinite}@keyframes levitate{0%{transform:translate(0,-8px)}100%{transform:translate(0,8px)}}</style>
        <div class="overlay">
          <div class="overlay-content">
              <svg class="overlay-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 84 81">
                  <path fill="#4B4B4B" fill-rule="evenodd" d="M11.9969 51.0003c0-8.2842 6.7062-15 15.0009-15h29.9813c8.2847 0 15.0008 6.7139 15.0008 15 0 8.2843-6.7062 15-15.0008 15H26.9978c-8.2848 0-15.0009-6.7139-15.0009-15Zm14.9958 6c-3.3128 0-5.9983-2.6863-5.9983-6s2.6855-6 5.9983-6 5.9983 2.6863 5.9983 6-2.6855 6-5.9983 6Zm29.9915 0c-3.3128 0-5.9983-2.6863-5.9983-6s2.6855-6 5.9983-6 5.9983 2.6863 5.9983 6-2.6855 6-5.9983 6Z" clip-rule="evenodd"></path>
                  <path fill="#4B4B4B" fill-rule="evenodd" d="M56.9842 53.0003c1.1042 0 1.9994-.8954 1.9994-2 0-1.1045-.8952-2-1.9994-2-1.1043 0-1.9994.8955-1.9994 2 0 1.1046.8951 2 1.9994 2Zm-29.9915 0c1.1042 0 1.9994-.8954 1.9994-2 0-1.1045-.8952-2-1.9994-2-1.1043 0-1.9994.8955-1.9994 2 0 1.1046.8951 2 1.9994 2Z" clip-rule="evenodd"></path>
                  <path fill="#4B4B4B" fill-rule="evenodd" d="M73.117 21.3401c8.8601 8.6755 8.8601 19.6602 8.8601 19.6602v20s0 20-39.9887 20c-39.98863 0-39.98863-20-39.98863-20v-20s0-10.9955 8.87323-19.6731L.269341 3.0024C-.283805 2.04648.0423145.822909.997747.269479 1.95318-.28395 3.17612.0423355 3.72927.998259L13.9665 18.6898c5.9241-4.4002 14.7808-7.6895 28.0219-7.6895 13.2516 0 22.1118 3.2945 28.0359 7.6999L80.2699.998259c.5532-.9559235 1.7765-1.282209 2.7321-.72878.9557.55343 1.2819 1.777001.7286 2.732921L73.117 21.3401ZM5.99863 41.0003v20c0-.0275.00697.0771.03791.2937.0646.4523.18645.9805.38171 1.5664.59007 1.7707 1.67323 3.5765 3.40772 5.3115 5.41543 5.4169 15.64703 8.8284 32.16243 8.8284 16.5155 0 26.7471-3.4115 32.1625-8.8284 1.7345-1.735 2.8177-3.5408 3.4077-5.3115.1953-.5859.3171-1.1141.3817-1.5664.031-.2166.0379-.3212.0379-.2937v-20c0-.1115-.0139-.4249-.06-.9098-.0825-.8663-.2333-1.8463-.4695-2.9099-.6798-3.0596-1.9035-6.1197-3.7974-8.9615-5.4823-8.2258-15.4655-13.2188-31.6629-13.2188-16.1973 0-26.1805 4.993-31.6628 13.2188-1.89397 2.8418-3.11766 5.9019-3.79737 8.9615-.23629 1.0636-.38703 2.0436-.46951 2.9099-.04616.4849-.06009.9098-.06009.9098Z" clip-rule="evenodd"></path>
              </svg>
              <div class="overlay-text">${overlayText}</div>
              <br><span id="bot-liker-additional-overlay-popup-info"></span>
          </div>
      </div>`
      },
      [overlayText]
    )
  }

  static async closeTabs(urlFilter) {
    await new Promise(async (resolve, reject) => {
      chrome.tabs.query({}, async function (tabs) {
        let removeTabs = tabs.filter(i => {
          // для пк использовался pinned, что бы не засорять вкладки. Сделать ли опционально?
          // return (i.url || '').includes('tiktok') && i.pinned
          return (i.url || '').includes(urlFilter)
        });

        let settings = await Settings.getSettings();
        for (let tab of removeTabs) {
          try {
            if (tab.id === await settings.common.mainTabId) {
              continue;
            }
            let tabAvailable = await new Promise(async (r) => {
              chrome.tabs.get(tab.id, () => r(chrome.runtime.lastError === undefined));
            });
            if (tabAvailable) {
              await chrome.tabs.remove([tab.id]);
            }
          } catch (e) {}
        }

        resolve(true);
      });
    });
  }

  needReqData() {
    return false;
  }

  needReqDataCustomUrl(taskType, taskObject, isMobile) {
    return false;
  }

  needReqDataComment(taskType) {
    return false;
  }

  needReqDataCommentUrl(taskType) {
    return '';
  }

  async getAdditionalAccountData(isMobile, taskType, taskObject, username, userId) {
    return {};
  }

  sleepMs(s) {
    return new Promise(r => setTimeout(() => r(), s));
  }

  scripting(func, args = [], resolveFunc = undefined) {
    if (resolveFunc === undefined) {
      resolveFunc = (injectionResults) => {
        return injectionResults === undefined ? false : injectionResults[0].result;
      }
    }

    return new Promise((resolve, reject) => {
      try {
        chrome.scripting
          .executeScript({
            target: {tabId: this.tab.id},
            func: func,
            args: args,
          }, (injectionResults) => {
            resolve(resolveFunc(injectionResults));
          })
      } catch (e) {
        debugError('BaseNetworkHandler', 'exception', `Exception: ${e.message}. В BaseNetworkHandler::scripting(${func.name}, ${JSON.stringify(args)})`);
        resolve(null);
      }
    })
  }
}