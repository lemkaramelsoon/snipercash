export const _functions = {
  getLogin: async (selectors, matches) => {
    return selectorHandler(selectors, matches);
  },
  checkLogin: async (selectors) => {
    return selectorHandler(selectors) == null;
  },
  isPageAvailable: async (isMobile, selectors) => {
    return selectorHandler(selectors) != null;
  },
  comment : async (comment, channelName, onlyCheck = false, selectors) => {
    const debug = (action, type = 'info', message = '') => {
      try {
        chrome.runtime.sendMessage({type: 'debug_scripting', message_type: type, message_context: 'instagram.functions.commentMobile', message_action: action, message_text: message});
      } catch (e) {}
    };
    const sleepMs = (ms) => {return new Promise(r => setTimeout(() => r(), ms));}
    const isCommentExist = () => {
      try {
        const commentsAuthors = selectorHandler(selectors.comments_authors) ?? [];
        if (commentsAuthors.length === 0) {
          debug(`Нет комментариев к посту`, 'error');
        }
        for (let i = 0; i < commentsAuthors.length; i++) {
          if (commentsAuthors[i].innerText === channelName) {
            return true;
          }
        }
        return false;
      }
      catch (e) {
        debug(`Неизвестная ошибка при попытке найти комментарий. Ошибка: ${e.message}`, 'error');
        return false;
      }
    };

    const writeComment = async (comment, commentEl) => {
      debug('Попытка написать. Клик, фокус', 'info');
      commentEl = selectorHandler(selectors.comment_input_el);
      commentEl.click();
      commentEl.focus();
      await sleepMs(600)
      commentEl = selectorHandler(selectors.comment_input_el);
      debug('Попытка написать. Вызываем евент вставки текста', 'info');
      var nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
      nativeInputValueSetter.call(commentEl, comment);
      var event = new Event('input', { bubbles: true});
      commentEl.dispatchEvent(event);
      debug('Попытка написать. Вставили текст', 'info');
      await sleepMs(3000);

      try {
        debug('Классы инпута. commentEl.classes: ' + commentEl.classList.toString(), 'info');
      } catch (e) {}
      try {
        debug('Попытка написать. commentEl.innerText: ' + commentEl.innerText, 'info');
      } catch (e) {}
    }
    // случайная задержка перед действием
    const rand = (min, max) => {
      return Math.floor(Math.random() * (max - min + 1)) + min
    }
    await sleepMs(rand(3, 6)*1000);

    if (isCommentExist()) {
      return true;
    }

    if (onlyCheck) {
      return false;
    }

    debug('Начинаем клик. Ищем инпут', 'info');
    const commentInputEl = selectorHandler(selectors.comment_input_el);
    if (commentInputEl == null) {
      debug('Не найден инпут комментария', 'error');
      return false;
    }

    debug('Инпут найден. Скролл', 'info');
    window.scrollBy(0,500);
    await sleepMs(1000);
    await writeComment(comment, commentInputEl);
    debug('Поиск кнопки сабмита', 'info');
    if (selectorHandler(selectors.comment_input_el_submit_button) == null) {
      debug('Кнопка сабмита не найдена, повтор', 'error');
      window.scrollBy(0,1500)
      await sleepMs(3000);
      await writeComment(comment, commentInputEl);
      await sleepMs(2000);
      debug('Поиск кнопки сабмита', 'info');
      if (selectorHandler(selectors.comment_input_el_submit_button) == null) {
        debug('Кнопка сабмита не найдена, повтор', 'error');
        window.scrollBy(0,1500)
        await sleepMs(5000);
        await writeComment(comment, commentInputEl);
        await sleepMs(3000);
      }
    }
    debug('Получение кнопки сабмита', 'info');
    if (selectorHandler(selectors.comment_input_el_submit_button) != null) {
      debug('Клик кнопки сабмита', 'info');
      selectorHandler(selectors.comment_input_el_submit_button).click();
    }
    else {
      debug('Кнопка сабмита ОКОНЧАТЕЛЬНО не найдена', 'error');
    }


    await sleepMs(2000);

    // Двойная проверка, бывает не успевает что-то смениться
    if (!isCommentExist()) {
      await sleepMs(5000);
      return isCommentExist();
    }
    else {
      return true;
    }
  },
  like : async (onlyCheck = false, isMobile = false, selectors) => {
    const sleep = (s) => {return new Promise(r => setTimeout(() => r(), s*1000));}
    const debug = (action, type = 'info', message = '') => {
      try {
        chrome.runtime.sendMessage({type: 'debug_scripting', message_type: type, message_context: 'instagram.functions.like', message_action: action, message_text: message});
      } catch (e) {}
    };
    const findButton = (isLike) => {
      const buttonSelectors = isLike ? 'like_button' : 'dislike_button';
      return selectorHandler(selectors[buttonSelectors]);
    }
    const rand = (min, max) => {
      return Math.floor(Math.random() * (max - min + 1)) + min
    }

    if (findButton(false) != null) {
      debug('Лайк уже стоит');
      return true;
    }

    if (onlyCheck) {
      return false;
    }

    await sleep(rand(2, 4));

    debug('Установка лайка')
    const buttonLike = findButton(true);
    if (buttonLike == null) {
      debug('Не найдена кнопка лайка', 'error');
      return false;
    }

    buttonLike.click();
    await sleep(2);

    debug('Проверка лайка')
    if (findButton(false) == null) {
      debug('Повторная проверка лайка')
      await sleep(5);
      return findButton(false) != null;
    }
    else {
      return true;
    }
  },
  subscribe : async (onlyCheck = false, isMobile = false, selectors) => {
    const debug = (action, type = 'info', message = '') => {
      try {
        chrome.runtime.sendMessage({type: 'debug_scripting', message_type: type, message_context: 'instagram.functions.subscribe', message_action: action, message_text: message});
      } catch (e) {}
    };
    const sleep = (s) => {return new Promise(r => setTimeout(() => r(), s*1000));}
    const findSubscribeButton = (isSubscribe) => {
      const buttonSelectors = isSubscribe ? 'subscribe_button' : 'unsubscribe_button';
      return selectorHandler(selectors[buttonSelectors])
    }
    const rand = (min, max) => {
      return Math.floor(Math.random() * (max - min + 1)) + min
    }

    if (findSubscribeButton(false) != null) {
      debug('Подписка уже стоит');
      return true;
    }

    if (onlyCheck) {
      return false;
    }

    await sleep(rand(2, 4));

    debug('Установка подписки')
    const button = findSubscribeButton(true);
    if (button == null) {
      debug('Не найдена кнопка подписки', 'error');
      return false;
    }

    button.click();
    await sleep(4);

    debug('Проверка подписки')
    if (findSubscribeButton(false) == null) {
      debug('Повторная проверка подписки')
      await sleep(5);
      return findSubscribeButton(false) != null;
    }
    else {
      return true;
    }
  },
}