let paths = JSON.parse(document.currentScript.dataset.data);
const getObjectValueBaPaths = (obj, paths) => {
  try {
    for (let path of paths) {
      obj = obj[path];
    }
    return obj;
  } catch (e) {
    return undefined;
  }
}
let foundUsername = getObjectValueBaPaths(window, paths);
document.currentScript.dataset.data = foundUsername === undefined ? "" : foundUsername;