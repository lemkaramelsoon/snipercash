let username = document.currentScript.dataset.data;
let foundUsername = document.body.innerHTML.search(username) === -1 ? "0" : "1";
document.currentScript.dataset.data = foundUsername;