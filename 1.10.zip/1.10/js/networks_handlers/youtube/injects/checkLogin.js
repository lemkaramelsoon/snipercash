let isLoginString = window.yt.config_.LOGGED_IN ? "1" : "0";
document.currentScript.dataset.data = isLoginString;

