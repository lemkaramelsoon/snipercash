export const _functions = {
  checkLogin: async () => {
    let result = await injectCode(chrome.runtime.getURL('js/networks_handlers/youtube/injects/checkLogin.js'));
    return result == 1;
  },
  checkLocationHref: async (query, fullMatch = false) => {
    return fullMatch
      ? location.href === query
      : location.href.indexOf(query) >= 0;
  },
  search: async (query, isMobile) => {
    const sleepMs = (s) => {return new Promise(r => setTimeout(() => r(), s));}

    if (isMobile) {
      let buttonSearchStart = document.querySelector(".icon-button.topbar-menu-button-avatar-button");
      buttonSearchStart.click();
      await sleepMs(500);
      let searchInputEl = document.querySelector("input.searchbox-input.title");
      searchInputEl.dispatchEvent(new Event('click'));
      searchInputEl.dispatchEvent(new Event('focus'));
      await sleepMs(500);
      searchInputEl.value = query;
      searchInputEl.dispatchEvent(new Event('paste', {bubbles: true, cancelable: true}));
      searchInputEl.dispatchEvent(new Event('input', {bubbles: true}));
      await sleepMs(500);
      document.querySelectorAll("form.searchbox-form.cbox button.icon-button")[1].click()
    }
    else  {
      let searchInputEl = document.querySelector("input#search")
      searchInputEl.dispatchEvent(new Event('click'));
      searchInputEl.dispatchEvent(new Event('focus'));
      await sleepMs(500);
      searchInputEl.value = query;
      searchInputEl.dispatchEvent(new Event('paste', {bubbles: true, cancelable: true}));
      searchInputEl.dispatchEvent(new Event('input', {bubbles: true}));
      await sleepMs(500);
      document.querySelector("#search-form").submit();
    }

    return true;
  },
  selectVideoInSearch : async (isMobile, id) => {
    const sleepMs = (s) => {return new Promise(r => setTimeout(() => r(), s));}
    const find = async () => {
      let foundVideo = undefined;
      // ищем видео
      let videos = isMobile
        ? document.querySelectorAll("ytm-video-with-context-renderer .details .media-item-info .media-item-metadata a")
        : document.querySelectorAll("#contents ytd-video-renderer #dismissible .text-wrapper #meta h3 a");
      for (let videoIndex = 0; videoIndex < videos.length; videoIndex++) {
        if (
          //videos[videoIndex].title === name &&
          videos[videoIndex].href.indexOf(id) >= 0
        ) {
          foundVideo = videos[videoIndex];
          break;
        }
      }

      // ищем шортсы
      videos = isMobile
        ? document.querySelectorAll("ytm-reel-item-renderer a.reel-item-endpoint")
        : document.querySelectorAll("#contents ytd-reel-item-renderer #dismissible #details h3.ytd-reel-item-renderer a");
      for (let videoIndex = 0; videoIndex < videos.length; videoIndex++) {
        if (
          videos[videoIndex].href.indexOf(id) >= 0
        ) {
          foundVideo = videos[videoIndex];
          break;
        }
      }

      return foundVideo;
    }

    let foundVideo = await find();
    if (foundVideo === undefined) {
      window.scrollBy(0,15000)
      await sleepMs(2000);
      window.scrollBy(0,15000)
      await sleepMs(2000);
      window.scrollBy(0,15000)
      await sleepMs(3000);

      foundVideo = await find();
    }

    if (foundVideo === undefined) {
      return false;
    }

    foundVideo.click();
    await sleepMs(1000);

    return true;
  },
  selectChannelInSearch : async (isMobile, channelUrl) => {
    const sleepMs = (s) => {return new Promise(r => setTimeout(() => r(), s));}
    const find = async () => {
      let foundChannel = undefined;

      let channels = isMobile
        ? document.querySelectorAll("ytm-compact-channel-renderer .compact-media-item a.compact-media-item-image")
        : document.querySelectorAll("#contents ytd-channel-renderer #content-section #info-section #main-link")
      for (let channelIndex = 0; channelIndex < channels.length; channelIndex++) {
        if (channels[channelIndex].href === channelUrl) {
          foundChannel = channels[channelIndex];
          break;
        }
      }

      return foundChannel;
    }

    let foundChannel = await find();

    if (foundChannel === undefined) {
      window.scrollBy(0,15000)
      await sleepMs(2000);
      window.scrollBy(0,15000)
      await sleepMs(2000);
      window.scrollBy(0,15000)
      await sleepMs(3000);

      foundChannel = await find();
    }

    if (foundChannel === undefined) {
      return false;
    }

    foundChannel.click();
    await sleepMs(1000);

    return true;
  },
  subscribe : async (onlyCheck = false, isMobile = false, selectors) => {
    const debug = (action, type = 'info', message = '') => {
      try {
        chrome.runtime.sendMessage({type: 'debug_scripting', message_type: type, message_context: 'youtube.functions.subscribe', message_action: action, message_text: message});
      } catch (e) {}
    };
    const sleep = (s) => {return new Promise(r => setTimeout(() => r(), s*1000));}
    const isSubscribe = () => {
      try {
        const _selectors = selectors['unsubscribe_button'][isMobile ? 'mobile' : 'pc'];
        return selectorHandler(_selectors) != null;
        /* return isMobile
          ? document.querySelector(".is-not-subscribed") === null
          : document.querySelector("#notification-preference-button").hasAttribute('invisible') === false; */
      } catch (e) {
        return false;
      }
    };
    const findSubscribeButton = () => {
      try {
        const _selectors = selectors['subscribe_button'][isMobile ? 'mobile' : 'pc'];
        return selectorHandler(_selectors);
      } catch (e) {
        return null;
      }
    }

    if (isSubscribe()) {
      debug('Подписка уже стоит')
      return true;
    }

    if (onlyCheck) {
      return false;
    }

    let subscribeButton = findSubscribeButton();
    if (subscribeButton == null) {
      debug('Не найдена кнопка подписки', 'warning')
      await sleep(3);
      subscribeButton = findSubscribeButton();
      if (subscribeButton == null) {
        debug('Не найдена кнопка подписки второй раз', 'error')
        return false;
      }
    }

    // случайная задержка перед действием
    const rand = (min, max) => {
      return Math.floor(Math.random() * (max - min + 1)) + min
    }
    await sleep(rand(3, 6));

    debug('Подписка')
    if (isMobile) {
      subscribeButton.dispatchEvent(
        new TouchEvent("click", {
          bubbles: true,
          cancelable: true
        })
      );
    }
    else {
      subscribeButton.dispatchEvent(
        new MouseEvent("click", {
          bubbles: true,
          cancelable: true
        })
      );
    }

    // ждем прогрузки всего
    await sleep(2);

    debug('Проверка пописки')
    if (!isSubscribe()) {
      debug('Повторная проверка подписки')
      await sleep(5);
      return isSubscribe();
    }
    else {
      return true;
    }
  },
  like : async (onlyCheck = false, isMobile = false, selectors) => {
    let isShorts = location.href.indexOf('shorts') >= 0;

    const sleep = (s) => {return new Promise(r => setTimeout(() => r(), s*1000));}
    const findLikeButton = () => {
      try {
        const _selectors = selectors['like_button'][isShorts ? 'shorts' : 'video'][isMobile ? 'mobile' : 'pc'];
        return selectorHandler(_selectors);
      } catch (e) {
        return null;
      }
    }
    const isLike = () => {
      try {
        const _selectors = selectors['dislike_button'][isShorts ? 'shorts' : 'video'][isMobile ? 'mobile' : 'pc'];
        return selectorHandler(_selectors) != null;
      } catch (e) {
        return false;
      }
    };
    const debug = (action, type = 'info', message = '') => {
      try {
        chrome.runtime.sendMessage({type: 'debug_scripting', message_type: type, message_context: 'youtube.functions.like', message_action: action, message_text: message});
      } catch (e) {}
    };

    if (isLike()) {
      debug('Лайк уже стоит')
      return true;
    }

    if (onlyCheck) {
      return false;
    }

    let likeButton = findLikeButton();
    if (likeButton == null) {
      debug('Не найдена кнопка лайка', 'warning')
      await sleep(3);
      likeButton = findLikeButton();
      if (likeButton == null) {
        debug('Не найдена кнопка лайка во второй раз', 'error')
        return false;
      }
    }

    // случайная задержка перед действием
    const rand = (min, max) => {
      return Math.floor(Math.random() * (max - min + 1)) + min
    }
    await sleep(rand(5, 10));

    debug('Установка лайка')
    if (isMobile) {
      likeButton.dispatchEvent(
        new TouchEvent("click", {
          bubbles: true,
          cancelable: true
        })
      );
    }
    else {
      likeButton.dispatchEvent(
        new MouseEvent("click", {
          bubbles: true,
          cancelable: true
        })
      );
    }

    // ждем прогрузки всего
    await sleep(2);

    // Двойная проверка, бывает не успевает что-то смениться
    debug('Проверка лайка')
    if (!isLike()) {
      debug('Повторная проверка лайка')
      await sleep(5);
      return isLike();
    }
    else {
      return true;
    }
  },
  commentDesktop : async (comment, channelName, onlyCheck = false) => {
    let isShorts = location.href.indexOf('shorts') >= 0;

    const debug = (action, type = 'info', message = '') => {
      try {
        chrome.runtime.sendMessage({type: 'debug_scripting', message_type: type, message_context: 'youtube.functions.commentDesktop', message_action: action, message_text: message});
      } catch (e) {}
    };
    const sleepMs = (ms) => {return new Promise(r => setTimeout(() => r(), ms));}
    const isCommentExist = () => {
      try {
        let commentsAuthors = document.querySelectorAll("#author-text");
        for (let commentAuthorIndex in commentsAuthors) {
          if (commentsAuthors[commentAuthorIndex].children !== undefined) {
            if (
              commentsAuthors[commentAuthorIndex].children.length > 0
              && commentsAuthors[commentAuthorIndex].children[0].innerText === channelName) {
              return true;
            } else if (commentsAuthors[commentAuthorIndex].innerText.indexOf(channelName) >= 0) {
              return true;
            }
          }
        }
        return false;
      } catch (e) {
        debug(`Неизвестная ошибка при попытке найти комментарий. Ошибка: ${e.message}`, 'error');
        return false;
      }
    };

    // случайная задержка перед действием
    const rand = (min, max) => {
      return Math.floor(Math.random() * (max - min + 1)) + min
    }
    await sleepMs(rand(3, 6)*1000);

    if (isShorts) {
      document.querySelector("ytd-reel-video-renderer[is-active] #comments-button button")?.click();
    }
    else {
      window.scrollBy(0, 600)
    }
    await sleepMs(3000);

    if (isCommentExist()) {
      return true;
    }

    if (onlyCheck) {
      return false;
    }

    document.querySelector("#simplebox-placeholder").click();
    await sleepMs(300);
    let textAreaEl = document.querySelector("#contenteditable-textarea");
    textAreaEl.dispatchEvent(new Event('focus'));
    await sleepMs(300);
    document.querySelector("#contenteditable-root").innerText = comment;
    await sleepMs(500);
    textAreaEl.dispatchEvent(new Event('input'));
    await sleepMs(1000);
    document.querySelector("#submit-button").click()
    await sleepMs(3500);

    // Двойная проверка, бывает не успевает что-то смениться
    if (!isCommentExist()) {
      await sleepMs(5000);
      return isCommentExist();
    }
    else {
      return true;
    }
  },
  commentMobile : async (comment, channelName, onlyCheck = false) => {
    let isShorts = location.href.indexOf('shorts') >= 0;

    const debug = (action, type = 'info', message = '') => {
      try {
        chrome.runtime.sendMessage({type: 'debug_scripting', message_type: type, message_context: 'youtube.functions.commentMobile', message_action: action, message_text: message});
      } catch (e) {}
    };
    const sleepMs = (ms) => {return new Promise(r => setTimeout(() => r(), ms));}
    const isCommentExist = () => {
      try {
        let commentsAuthors = document.querySelectorAll(".comment-title");
        for (let i = 0; i < commentsAuthors.length; i++) {
          if (
            commentsAuthors[i].children.length > 0
            && commentsAuthors[i].children[0].innerText === channelName) {
            return true;
          }
          else if (commentsAuthors[i].innerText.indexOf(channelName) >= 0) {
            return true;
          }
        }
        return false;
      } catch (e) {
        debug(`Неизвестная ошибка при попытке найти комментарий. Ошибка: ${e.message}`, 'error');
        return false;
      }
    };

    // случайная задержка перед действием
    const rand = (min, max) => {
      return Math.floor(Math.random() * (max - min + 1)) + min
    }
    await sleepMs(rand(3, 6)*1000);

    if (isShorts) {
      document.querySelector(".icon-shorts_comment button")?.click();
      await sleepMs(2000);
    }
    else {
      window.scrollBy(0, 300)
      await sleepMs(500);
      document.querySelector(".comments-entry-point-header")?.click();
      await sleepMs(1000);
    }

    if (isCommentExist()) {
      return true;
    }

    if (onlyCheck) {
      return false;
    }

    document.querySelector(".comment-simplebox-reply").click()
    document.querySelector(".comment-simplebox-reply").dispatchEvent(new Event('focus'));
    await sleepMs(600);
    document.querySelector(".comment-simplebox-reply").value = comment;
    await sleepMs(300);
    document.querySelector(".comment-simplebox-reply").dispatchEvent(new Event('input'));
    await sleepMs(1000);
    document.querySelector(".comment-simplebox-buttons.cbox").getElementsByTagName('button')[1].click()
    await sleepMs(3500);

    // Двойная проверка, бывает не успевает что-то смениться
    if (!isCommentExist()) {
      await sleepMs(5000);
      return isCommentExist();
    }
    else {
      return true;
    }
  },
  watch : async (seconds, isMobile) => {
    let isShorts = location.href.indexOf('shorts') >= 0;

    let currentSeconds = 0;
    let commonSeconds = 0;

    const debug = (action, type = 'info', message = '') => {
      try {
        chrome.runtime.sendMessage({type: 'debug_scripting', message_type: type, message_context: 'youtube.functions.watch', message_action: action, message_text: message});
      } catch (e) {}
    };
    const sleepMs = (ms) => {return new Promise(r => setTimeout(() => r(), ms));}
    const isPlayingNow = () => {
      return document.querySelector(".playing-mode") != null;
    }
    const startPlaying = () => {
      if (isShorts) {
        if (isMobile) {
          document.querySelector(".reel-player-overlay-main-content")?.click();
        }
        else {
          document.querySelector("ytd-reel-video-renderer[is-active] .html5-video-player")?.click();
        }
      }
      else {
        let btn = document.querySelector(".ytp-play-button.ytp-button");
        if (btn !== undefined && btn !== null) {
          btn.click();
        }
        else {
          document.querySelector(".html5-video-player")?.click();
        }
      }
    }
    const checkAndStartPlaying = () => {
      try {
        if (isPlayingNow()) {
          return true;
        }
        else {
          startPlaying();
          return false;
        }
      } catch (e) {
        throw new Error("buttons_not_found");
      }
    };

    return await new Promise((resolve, reject) => {
      let addInfo = document.querySelector('#bot-liker-additional-overlay-popup-info');
      setInterval(function () {
        let isPlayingNow = false;
        try {
          isPlayingNow = checkAndStartPlaying();
        } catch (e) {
          debug(`Неизвестная ошибка при просмотре ${currentSeconds} из ${seconds}. Ошибка: ${e.message}`, 'error');
          if (addInfo !== null) {addInfo.innerText = '';}
          resolve(false)
        }

        commonSeconds++;
        if (isPlayingNow) {
          currentSeconds++;
        }

        if (currentSeconds > seconds) {
          if (addInfo !== null) {addInfo.innerText = '';}
          debug(`Успешный просмотр ${currentSeconds} из ${seconds}`);
          resolve(true);
        }
        if (commonSeconds/2 > seconds) { // в случае если не просмотр тянется уже в два раза дольше, вернуть.
          debug(`Не удалось просмотреть. Потратили ${commonSeconds} из ${seconds}`, 'error');
          if (addInfo !== null) {addInfo.innerText = '';}
          resolve(false);
        }

        if (addInfo !== null) {
          addInfo.innerText = ` Watching: ${currentSeconds} s. of ${seconds} s. (total ${commonSeconds} s.)`;
        }
      }, 1000)
    });
  },
  getChannelNameMobile : async (selectorsMenuButton, selectorsUsername, selectorsChannel) => {
    const sleepMs = (ms) => {return new Promise(r => setTimeout(() => r(), ms));}
    try {
      selectorHandler(selectorsMenuButton).click();
      await sleepMs(500);
      let channel = selectorHandler(selectorsChannel);
      channel = channel.replace('https://m.youtube.com/channel/', '');
      channel = channel.replace('/', '');
      return {
        username: selectorHandler(selectorsUsername),
        channel: channel,
      };
    } catch (e) {
      return null;
    }
  },
  getChannelNameDesktop : async (selectorsMenuButton, selectorsUsername, selectorsChannel) => {
    const sleepMs = (ms) => {return new Promise(r => setTimeout(() => r(), ms));}
    try {
      selectorHandler(selectorsMenuButton).click();
      await sleepMs(3000);
      let channel = selectorHandler(selectorsChannel);
      channel = channel.replace('https://www.youtube.com/channel/', '');
      channel = channel.replace('/', '');
      return {
        username: selectorHandler(selectorsUsername),
        channel: channel,
      };
    } catch (e) {
      return null;
    }
  },
  findUsername : async (username) => {
    try {
      return await injectCode(chrome.runtime.getURL('js/networks_handlers/youtube/injects/findUsername.js'), username);
    } catch (e) {
      return "0";
    }
  },
  getUsernameFromJson : async (paths) => {
    let result = undefined;
    for (let path of paths) {
      result = await injectCode(chrome.runtime.getURL('js/networks_handlers/youtube/injects/getUsername.js'), JSON.stringify(path));
      if (result !== "") {
        return result;
      }
    }
    return undefined;
  },
  isVideoAvailable: async (isMobile) => {
    let isShorts = location.href.indexOf('shorts') >= 0;

    if (isShorts) {
      if (isMobile) {
        return document.body.children.length > 3;
      }
      else {
        return document.body.children.length > 3;
      }
    }
    else {
      if (isMobile) {
        return document.querySelector('ytm-player-error-message-renderer') === null
      }
      else {
        return document.querySelector('yt-playability-error-supported-renderers')?.children?.length === 0
      }
    }

  },
  isAccountAvailable: async (isMobile) => {
    if (isMobile) {
      return document.body.children.length > 3;
    }
    else {
      return document.querySelector("#error-page") === null;
    }
  }
}