import {localStorage} from "./storage.js";
import {Tiktok} from "../networks_handlers/tiktok/tiktok.js";
import {Youtube} from "../networks_handlers/youtube/youtube.js";
import {Helpers} from "./helpers.js";
import {Instagram} from "../networks_handlers/instagram/instagram.js";

const templateCommon = {
  version: '1.10',

  first_open: true,
  event_sent_first_open: false,
  work_enable: false,
  work_fully_stop: true,
  work_pause: false,
  work_seconds: 0,
  pause_seconds: 0,
  sleep_interval_after_minutes: undefined,
  sleep_minutes: undefined,
  current_task_id: undefined,
  current_task: undefined,
  current_network: undefined,
  tg_chat_id: undefined,
  tg_enable: true,
  is_mobile: undefined,
  language: 'en',
  open_modal_background_work: true,

  // @deprecated
  log: '',

  logData: [],
  debugLog: [],
  mainTabId: undefined,
  errorsInARowCount: 0,

  tiktok_enable: false,
  youtube_enable: false,
  instagram_enable: false,

  recheck: true,

  backgroundMode: false,
  is_allow_get_data_tiktok: true,
  is_allow_get_data_instagram: true,
  allow_timer_instagram: 0,
  allow_timer_tiktok: 0,
  auth_active: 1800,
  auth_inactive: 3600,
};
const templateTask = {
  enable: false,
  limit: 1,
  timeout_between_min: 2,
  timeout_between_max: 5,

  counter: 0,
  success_counter: 0,
  error_counter: 0,
  error_counter_in_a_row: 0,
  counter_last_clear_at: undefined,
};

/**
 * Для добавления новой платформы, необходимо добавить новые свойства класса и в конструкторе добавить в platforms. Добавить tiktok_enable, youtube_enable... Добавить дефолтные настройки в setDefaultTasksSettings
 * Так же необходимо добавить переводы
 * Так же необходимо добавить в разметку + показывать расширение на новой соц сети или задании (checkShowMainBody())
 * Так же необходимо для новой соцсети прописать домены в манифесте для разрешения + в background.js домены для получение данных запросов
 * Для добавления нового действия, необходимо добавить в объект платформы новое действие, указа ть для нео дефолтные значения в setDefaultTasksSettings
 */
export class Settings {
  static settings;

  isDebug = false;
  getlike = undefined;
  network = undefined;

  common = templateCommon;

  platforms = {};

  tiktok = {
    tasks: {
      subscribe: this.createObjectFromTemplate(templateTask, 'tiktok', 'tasks.subscribe.', new Tiktok(), 'subscribe'),
      like: this.createObjectFromTemplate(templateTask, 'tiktok', 'tasks.like.', new Tiktok(), 'like'),
      watch: this.createObjectFromTemplate(templateTask, 'tiktok', 'tasks.watch.', new Tiktok(), 'watch'),
    },
  };

  youtube = {
    tasks: {
      subscribe: this.createObjectFromTemplate(templateTask, 'youtube', 'tasks.subscribe.', new Youtube(), 'subscribe'),
      like: this.createObjectFromTemplate(templateTask, 'youtube', 'tasks.like.', new Youtube(), 'like'),
      watch: this.createObjectFromTemplate(templateTask, 'youtube', 'tasks.watch.', new Youtube(), 'watch'),
      comment: this.createObjectFromTemplate(templateTask, 'youtube', 'tasks.comment.', new Youtube(), 'comment'),
    },
  };

  instagram = {
    tasks: {
      comment: this.createObjectFromTemplate(templateTask, 'instagram', 'tasks.comment.', new Instagram(), 'comment'),
      like: this.createObjectFromTemplate(templateTask, 'instagram', 'tasks.like.', new Instagram(), 'like'),
      subscribe: this.createObjectFromTemplate(templateTask, 'instagram', 'tasks.subscribe.', new Instagram(), 'subscribe'),
    },
  };

  constructor() {
    this.common = this.createObjectFromTemplate(templateCommon, 'common', '');
    this.platforms = Object.assign({}, {
      tiktok: this.tiktok,
      youtube: this.youtube,
      instagram: this.instagram,
    });
  }

  /**
   * ЗДЕСЬ ПРОПИСЫВАЮТСЯ ДЕФОТЛНЫЕ ЗНАЧЕНИЯ
   */
  setDefaultTasksSettings() {
    this.common.is_allow_get_data_tiktok = true;
    this.common.is_allow_get_data_instagram = true;
    this.common.allow_timer_instagram = 0;
    this.common.allow_timer_tiktok = 0;
    this.common.auth_active = 1800;
    this.common.auth_inactive = 3600;

    this.common.log = '';
    // this.common.logData = [];
    // this.common.debugLog = [];

    this.common.tiktok_enable = false;
    this.tiktok.tasks.subscribe.enable = false;
    this.tiktok.tasks.subscribe.limit = 200;
    this.tiktok.tasks.subscribe.timeout_between_min = 2;
    this.tiktok.tasks.subscribe.timeout_between_max = 15;
    this.tiktok.tasks.like.enable = false;
    this.tiktok.tasks.like.limit = 500;
    this.tiktok.tasks.like.timeout_between_min = 2;
    this.tiktok.tasks.like.timeout_between_max = 15;
    this.tiktok.tasks.watch.enable = false;
    this.tiktok.tasks.watch.limit = 10000;
    this.tiktok.tasks.watch.timeout_between_min = 2;
    this.tiktok.tasks.watch.timeout_between_max = 15;

    this.common.youtube_enable = false;
    this.youtube.tasks.subscribe.enable = false;
    this.youtube.tasks.subscribe.limit = 75;
    this.youtube.tasks.subscribe.timeout_between_min = 2;
    this.youtube.tasks.subscribe.timeout_between_max = 15;
    this.youtube.tasks.like.enable = false;
    this.youtube.tasks.like.limit = 200;
    this.youtube.tasks.like.timeout_between_min = 2;
    this.youtube.tasks.like.timeout_between_max = 15;
    this.youtube.tasks.watch.enable = false;
    this.youtube.tasks.watch.limit = 10000;
    this.youtube.tasks.watch.timeout_between_min = 2;
    this.youtube.tasks.watch.timeout_between_max = 15;
    this.youtube.tasks.comment.enable = false;
    this.youtube.tasks.comment.limit = 100;
    this.youtube.tasks.comment.timeout_between_min = 2;
    this.youtube.tasks.comment.timeout_between_max = 15;

    this.common.instagram_enable = false;
    this.instagram.tasks.comment.enable = false;
    this.instagram.tasks.comment.limit = 100;
    this.instagram.tasks.comment.timeout_between_min = 2;
    this.instagram.tasks.comment.timeout_between_max = 15;
    this.instagram.tasks.like.enable = false;
    this.instagram.tasks.like.limit = 100;
    this.instagram.tasks.like.timeout_between_min = 2;
    this.instagram.tasks.like.timeout_between_max = 15;
    this.instagram.tasks.subscribe.enable = false;
    this.instagram.tasks.subscribe.limit = 100;
    this.instagram.tasks.subscribe.timeout_between_min = 2;
    this.instagram.tasks.subscribe.timeout_between_max = 15;
  }

  createObjectFromTemplate(template, network, path, handler, execFunc) {
    const save = (param, value) => this.save(network, `${path}${param}`, value);
    const load = (param, defaultValue) => this.load(network, `${path}${param}`, defaultValue);
    let obj = {};
    for (let param in template) {
      Object.defineProperty(obj, param, {
        set (value) {save(param, value)},
        get () {return load(param, template[param])},
      })
    }
    obj.handler = handler;
    obj.execFunc = execFunc;
    return obj;
  }

  static async getSettings() {
    if (this.settings === undefined) {
      this.settings = new Settings();
    }
    return this.settings;
  }

  createStorageKey(params) {
    return `${params.network}-${params.param}`;
  }

  async save(network, param, value) {
    try {
      await localStorage.setItem(this.createStorageKey({network: network, param: param}), value);
      return;
    } catch (e) {
      if (e.message === 'Extension context invalidated') {
        throw e;
      }

      if (e.message === 'QUOTA_BYTES quota exceeded') {
        let debugLog = await this.common.debugLog;
        debugLog = debugLog.slice(0, debugLog.length / 2);
        this.common.debugLog = debugLog;
        let logData = await this.common.logData;
        logData = logData.slice(0, logData.length / 2);
        this.common.logData = logData;
      }
    }

    try {
      await localStorage.setItem(this.createStorageKey({network: network, param: param}), value);
      return;
    } catch (e) {
      if (e.message === 'QUOTA_BYTES quota exceeded') {
        this.common.debugLog = [];
        this.common.logData = [];
      }
    }

    await localStorage.setItem(this.createStorageKey({network: network, param: param}), value);
  }

  async load(network, param, defaultValue) {
    let value = await localStorage.getItem(this.createStorageKey({network: network, param: param}))
    if (value === undefined) {
      value = defaultValue;
    }
    return value;
  }

  index(obj, is, value) {
    if (typeof is == 'string')
      return this.index(obj,is.split('.'), value);
    else if (is.length === 1 && value !== undefined)
      return obj[is[0]] = value;
    else if (is.length === 0)
      return obj;
    else
      return this.index(obj[is[0]],is.slice(1), value);
  }

  async getBaseUrl() {
    let baseUrl = 'https://getlike.io';
    switch (await this.common.language) {
      case 'ru':
        baseUrl = 'https://getlike.io'
        break;
      case 'en':
      default:
        baseUrl = 'https://getlike.io/en'
        break;
    }

    return baseUrl;
  }

  checkShowMainBody(url) {
    return (/getlike\.io(|\/en)\/tasks\/tiktok\/(subscribe|like|watch|all)/i.test(url))
    || (/getlike\.io(|\/en)\/tasks\/youtube\/(subscribe|like|comment|watch|all)/i.test(url))
    || (/getlike\.io(|\/en)\/tasks\/instagram\/(comment|like|subscribe|all)/i.test(url));
  }

  async clearAll() {
    return localStorage.clearAll();
  }

  wipeAllCounters() {
    for(let platformName in this.platforms) {
      let platform = this.platforms[platformName];
      for(let taskName in platform.tasks) {
        this.wipeCounters(platformName, taskName);
      }
    }
  }

  wipeCounters(network, task) {
    this[network].tasks[task].counter = 0;
    this[network].tasks[task].success_counter = 0;
    this[network].tasks[task].error_counter = 0;
    this[network].tasks[task].error_counter_in_a_row = 0;
  }

  /**
   * Сброс счетчиков, можно указать в настройках соцсетей для своей логики для каждой соцсети
   */
  async checkAndWipeAllCounters() {
    for(let platformName in this.platforms) {
      let platform = this.platforms[platformName];
      for(let taskName in platform.tasks) {
        await this.checkAndWipeCounters(platformName, taskName);
      }
    }
  }

  /**
   * Сброс счетчиков соцсети
   */
  async checkAndWipeCounters(network, task) {
    let lastClearAt = await this[network].tasks[task].counter_last_clear_at;
    if (
      lastClearAt === undefined
      || (new Date() - new Date(lastClearAt) > 86400000)
    ) {
      let date = new Date();
      this.common.work_seconds = 0;
      this[network].tasks[task].counter_last_clear_at = new Date(`${date.getFullYear()}-${date.getMonth()+1}-${date.getDate()} 00:00:00`).valueOf();
      this.wipeCounters(network, task);
    }
  }

  /**
   * Формирует массив задач, у которых еще не достигнуты лимиты
   * @returns {Promise<*[]>}
   */
  async getTasksWithoutLimit() {
    let tasks = [];

    for(let platformName in this.platforms) {
      let platform = this.platforms[platformName];
      for (let taskName in platform.tasks) {
        let task = platform.tasks[taskName];
        let platformEnable = await this.common[`${platformName}_enable`];
        let taskEnable = await task.enable;
        if (!taskEnable || !platformEnable) {
          continue;
        }

        let limit = parseInt(await task.limit);
        let counter = parseInt(await task.counter);
        if (counter >= limit) {
          continue;
        }

        tasks.push({
          network: platformName,
          task: taskName,
        });
      }
    }

    return tasks;
  }

  async addLogInfo(message, event, taskId, url, taskActionType, network) {
    this.addLog(message, event, 'info', taskId, url, taskActionType, network)
  }

  async addLogError(message, event, taskId, url, taskActionType, network) {
    this.addLog(message, event, 'error', taskId, url, taskActionType, network)
  }

  async addLog(message, event, type, taskId, url, taskActionType, network) {
    let date = new Date();
    let dateStr = date.toLocaleDateString();
    let timeStr = date.toLocaleTimeString("en-GB", {hour12:false, hour:"2-digit",minute:"2-digit", second:"2-digit"});
    let arr2 = timeStr.split(":");
    let H = arr2[0];
    let i = arr2[1];
    let s = arr2[2];


    this.common.log = '';
    // let log = await this.common.log;
    // log = `${H}:${i}:${s} - ${message}<br>` + log;
    // this.common.log = log;

    // Рандомная задержка, что бы хоть как то избежать race condition
    await Helpers.sleepMs(Helpers.rand(10,300));

    let logData = await this.common.logData;
    logData.unshift({
      date: `${dateStr} ${timeStr}`,
      event: event,
      type: type,
      message: message,
      task_id: taskId,
      url: url,
      task_action_type: taskActionType,
      network: network,
    });
    this.common.logData = logData;

    const networkLog = network ? `_${network}` : '';
    this.addDebugLog(message, `log_${type}`, `log${networkLog}_${taskActionType}_${taskId}`, event);
  }

  async addDebugLog(message, type = undefined, context = undefined, action = undefined) {
    // блокировка лога
    type = type === undefined ? 'info' : type;
    context = context === undefined ? 'general' : context;
    action = action === undefined ? 'no_action' : action;
    message = message === undefined ? '' : ` - ${message}`;

    let date = new Date();
    let dateStr = date.toLocaleDateString();
    let timeStr = date.toLocaleTimeString("en-GB", {hour12:false, hour:"2-digit",minute:"2-digit", second:"2-digit"});

    // Рандомная задержка, что бы хоть как то избежать race condition
    let text = `${dateStr} ${timeStr} - ${type} - ${context} - ${action}${message}`;
    await Helpers.sleepMs(Helpers.rand(10,300));

    let debugLog = await this.common.debugLog;
    if (debugLog.length > 100000) {
      debugLog = debugLog.slice(0, 99999);
    }
    debugLog.unshift(text);
    this.common.debugLog = debugLog;
  }
}