import {Settings} from "./settings.js";

export const debugInfo = async (context, action, msg) => {
  await debug(msg, 'info', context, action);
}

export const debugWarning = async (context, action, msg) => {
  await debug(msg, 'warning', context, action);
}

export const debugError = async (context, action, msg) => {
  await debug(msg, 'error', context, action)
}

export const debug = async (msg, type, context, action) => {
  let setting = await Settings.getSettings();
  await setting.addDebugLog(msg, type, context, action);
}