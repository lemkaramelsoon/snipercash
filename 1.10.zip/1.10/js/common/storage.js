export const localStorage = {
  getAllItems: () => chrome.storage.local.get(),
  getItem: async key => (await chrome.storage.local.get(key))[key],
  setItem: (key, val) => chrome.storage.local.set({[key]: val}),
  removeItem: key => chrome.storage.local.remove(key),
  clearAll: () => chrome.storage.local.clear(),
};