const nullthrows = (v) => {
    if (v == null) throw new Error("it's a null");
    return v;
}

function injectCode(src, dataValue = undefined, isDeleteScript = true) {
    return new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = src;
        if (dataValue !== undefined) {
            script.setAttribute('data-data', dataValue);
        }
        script.onload = function() {
            resolve(this.dataset.data !== undefined ? this.dataset.data : this.textContent);
            if (isDeleteScript) {
                this.remove();
            }
        };
        nullthrows(document.documentElement || document.head).appendChild(script);
    })
}

function injectCodeCallback(id, src, callback) {
    const script = document.createElement('script');
    script.setAttribute('id', id);
    script.src = src;
    script.onload = function() {
        callback(this.textContent);
        this.remove();
    };
    //nullthrows(document.head || document.documentElement).appendChild(script);
    //document.documentElement.appendChild(script);
}

const selectorHandler = (selectors = [], matches = []) => {
    const exec = (elements, context, functionName, args) => {
        var namespaces = elements.split(".");
        for(var i = 0; i < namespaces.length; i++) {
            context = context[namespaces[i]];
        }
        try {
            return functionName !== undefined
              ? context[functionName](args)
              : context;
        } catch (e) {
            return null;
        }
    }
    const checkMatches = (foundElement) => {
        if (matches.length === 0) {
            return true;
        }
        if (foundElement !== null) {
            for (let matchesIndex = 0; matchesIndex < matches.length; matchesIndex++) {
                if (foundElement === matches[matchesIndex]) {
                    return true;
                }
            }
        }
        return false;
    }

    let foundElement = null;
    for (const index in selectors) {
        if (typeof selectors[index] === 'object') {
            let element = null;
            try {
                if (selectors[index]['index'] !== undefined) {
                    const elements = document.querySelectorAll(selectors[index]['query'])
                    element = elements[selectors[index]['index']];
                } else {
                    element = document.querySelector(selectors[index]['query']);
                }
            } catch (e) {}
            if (element !== null) {
                foundElement = exec(selectors[index]['elements'], element, selectors[index]['func'], selectors[index]['args']);
                if (foundElement !== null && checkMatches(foundElement)) {
                    if (foundElement.length === undefined) {
                        break
                    } else if (foundElement.length > 0) {
                        break;
                    }
                }
            }
        }
        else {
            foundElement = document.querySelector(selectors[index]);
            if (foundElement !== null && checkMatches(foundElement)) {
                break;
            }
        }
    }
    return foundElement;
}

const getObjectValueBaPathsHandler = (obj, paths, allowUndefined = false) => {
    let result = undefined;
    for (let path of paths) {
        result = getObjectValueBaPaths(obj, path)
        if (result === undefined) {
            if (allowUndefined) {
                return result;
            }
            else {
                continue;
            }
        }
        return result;
    }
}

const getObjectValueBaPaths = (obj, paths) => {
    try {
        for (let path of paths) {
            obj = obj[path];
        }
        return obj;
    } catch (e) {
        return undefined;
    }
}

// TODO: переписать все общие функции скриптов (sleep, rand, debug) сюда