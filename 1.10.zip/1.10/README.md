Для релиза
1. Сменить версию на нужную в settings.js, manifest.json
2. Обфусцировать через https://codebeautify.org/javascript-obfuscator следующие файлы (положить в *_obf.js)
   > background.js
   > getlike.js
   > work.js
   > tiktok.js
   > youtube.js
   > instagram.js
   
3. Скопировать в отдельную папку проекту
4. Удалить оттуда все файлы связанные с IDE и GIT
5. Удалить из form_settings2.html тестовые элементы
6. В Settings установить isDebug = false;
7. Содержимым из файлов *_obf.js заменить обычные файлы. Должны остаться только обфусцированные данные, но без _obf.js